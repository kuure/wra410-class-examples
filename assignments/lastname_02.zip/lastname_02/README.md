Please detail your process, any people you may have worked with, specific
tutorials that may have found useful, tales of your interactions with
Chat GPT, or anything else you might want to document in the space below:

---
