const demoButton = document.querySelector("button")

demoButton.addEventListener("click", () => {
	console.log("Button Was Clicked")
})

