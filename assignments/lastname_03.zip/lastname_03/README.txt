Please add any notes, links to resources, names of collaborators, or other
items of interest here:

-----
