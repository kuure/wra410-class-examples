# Assignment 03

Please list any tutorials, resources, collaborators, issues, errors, dead
ends, revelations, or other details below:

