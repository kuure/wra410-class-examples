const treats = [
	{ 
		"name" : "Almond Joy",
		"category" : "chocolate",
	},	
	{ 
		"name" : "Kit Kat",
		"category" : "chocolate",
	},	
	{ 
		"name" : "Starburst",
		"category" : "candy",
	},	
	{ 
		"name" : "Gummi Worms",
		"category" : "candy",
	},	
	{ 
		"name" : "Raisins",
		"category" : "terrible",
	},	
	{ 
		"name" : "Rock",
		"category" : "charlieBrown",
	},	
]

console.log(treats)
