// variables to handle the two things we need to interact with 
const input = document.querySelector(".inputBox") 
const output = document.querySelector(".outputBox")


// 7. code that listens for the input event on the text box
input.addEventListener('input', () => {

	// 8. code that grabs the current value of the input box
	

	// 9. code that randomly upper or lowercases each letter of the string


	// 10. code that puts the text from the input into the output container


})





