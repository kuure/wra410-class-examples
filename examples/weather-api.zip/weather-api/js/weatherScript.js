// the weather API 

//const url = "https://api.weather.gov/gridpoints/MQT/114,96/";
//const url = "https://api.weather.gov/gridpoints/GRR/82,39/forecast"
