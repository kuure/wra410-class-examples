// the element we want to access later
const nav = document.querySelector("nav")


// how do we encode our navigation?
const navLinks = {

}


// now what?


